import random
K = 3
dataPoints = 100

def findNearestCluster(observation, centroids):
    ChiSquareArray = []
    for i in range(len(centroids)):
        ChiSquare = 0
        for j in range(len(centroids[i])):
            ObsVal = observation[j]
            ExpVal = centroids[i][j]
            try:
                ChiSquare += (ObsVal - ExpVal) ** 2 / ExpVal
            except:
                ChiSquare += (ObsVal - ExpVal) ** 2
                
        ChiSquareArray.append(ChiSquare)
        #print(len(centroids))
        
    return ChiSquareArray.index(min(ChiSquareArray))
    

salaryFile = open('Salary.csv', 'r')
salaryList = []

categoryStr = salaryFile.readline()
categoryStr = categoryStr.replace('\n', '')
categoryList = categoryStr.split(',')

for i in range(12, -1, -1):
    categoryList.pop(i)

dimensions = len(categoryList)

for i in range(dataPoints):
    salaryStr = salaryFile.readline()
    salaryStr = salaryStr.replace('\n', '')
    salaryValues = salaryStr.split(',')
    salaryLen = len(salaryValues) - 1
    
    while(salaryLen >= 0):
        try:
            salaryValues[salaryLen] = float(salaryValues[salaryLen])
        except:
            salaryValues.pop(salaryLen)
        
        salaryLen -= 1
        
    for j in range(6):
        salaryValues.pop(0)
    
    if (len(salaryValues) == dimensions):
        salaryList.append(salaryValues)
    
#K-Means Initialization-----------------------------------------------------------
clusters = []
centroids = []

for i in range(K):
    clusters.append([])

for i in range(len(salaryList)):
    clusterIndex = random.randint(0, K-1)
    clusters[clusterIndex].append(salaryList[i])

for i in clusters:
    if (len(i) == 0):
        done = False
        while (not done):
            sourceIndex = random.randint(0, K-1)
            source = clusters[sourceIndex]
            if (source != i and len(source) > 1):
                sourceSalaryIndex = random.randint(0, len(source) - 1)
                sourceSalary = source[sourceSalaryIndex]
                source.pop(sourceSalaryIndex)
                i.append(sourceSalary)
                done = True

#print(clusters)
for i in range(len(clusters)):
    centroid = []
    for j in range(dimensions):
        element = 0
        for k in range(len(clusters[i])):
            element += clusters[i][k][j]
            
        element = element / len(clusters[i])
        centroid.append(element)
        
    centroids.append(centroid)

#Assignment and Update Steps
done = False
while (not done):
    done = True
    for i in clusters: #For every cluster
        for j in i: #For every data observation 
            
            targetClusterIndex = findNearestCluster(j, centroids)
            currentClusterIndex = clusters.index(i)
            targetCluster = clusters[targetClusterIndex]
            currentCluster = clusters[currentClusterIndex]
            
            if (targetCluster != currentCluster):
                currentCluster.remove(j)
                targetCluster.append(j)
                done = False
                
    for i in range(len(clusters)):
        centroid = []
        for j in range(dimensions):
            element = 0
            for k in range(len(clusters[i])):
                element += clusters[i][k][j]
                
            element = element / len(clusters[i])
            centroid.append(element)
            
        centroids[i] = centroid
                
for i in range(len(centroids)):
    for j in range(len(centroids[i])):
        centroids[i][j] = round(centroids[i][j], 2)

print("CLUSTERS")
print("-------------------------------------")
print(clusters)
print()
print("CENTROIDS")
print("-------------------------------------")
print(centroids)
salaryFile.close()
    

